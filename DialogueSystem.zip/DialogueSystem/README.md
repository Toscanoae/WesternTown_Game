# Ink + Unity Dialogue System

This is a sample project to show a simple integration of Ink and Unity.

The branches in this repo follow implementation for the video series where these are implemented in a step by step manner. The video series can be found at the below link.

https://www.youtube.com/watch?v=KSRpcftVyKg&list=PL3viUl9h9k78KsDxXoAzgQ1yRjhm7p8kl

Please feel free to take anything from this example and use it however you'd like!
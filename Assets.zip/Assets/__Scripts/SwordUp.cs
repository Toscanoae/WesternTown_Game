using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwordUp : MonoBehaviour
{
    private GameObject superSword;
    private Dray       dray;
    private GameObject sword;
    private Collider2D      colld;
    public int multiplier = 3;

    // Start is called before the first frame update
    void Start()
    {
        Transform swordS = transform.Find( "SuperSword" );
        superSword = swordS.gameObject; 
        superSword.SetActive(false);

    }

     void OnTriggerEnter2D (Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
           Transform swordT = transform.Find( "Sword" );                         // a
         sword = swordT.gameObject;
         sword.SetActive(false); 

            
         Transform swordS = transform.Find( "SuperSword" );
         //superSword = swordS.gameObject; 
         superSword.SetActive(true);

         // Find the Sword child of SwordController
         //Transform swordS = transform.Find( "SuperSword" );                         // a
         if ( swordS == null ) {
             Debug.LogError("Could not find Sword child of SwordController.");
             return;
         }
         //superSword = swordS.gameObject;    
         
         // Find the Dray component on the parent of SwordController
         dray = GetComponentInParent<Dray>();                                  // b
         if ( dray == null ) {
             Debug.LogError("Could not find parent component Dray.");
             return;
         }
         
         // Deactivate the sword
         superSword.SetActive(false);                                               // c
        }
    }

    

    // Update is called once per frame
    void Update()
    {
        transform.rotation = Quaternion.Euler( 0, 0, 90*dray.facing );        // d
        superSword.SetActive(dray.mode == Dray.eMode.attack);
    }
}

 using UnityEngine;
 
 public class DamageEffect : MonoBehaviour {
     [Header("Inscribed")]
     public int  damage    = 1;
     public bool knockback = true;
 
     // void Start() {…}  // Please delete the unused Start() and Update() methods
     // void Update() {…}
 }
﻿using System.Collections;
 using System.Collections.Generic;
 using UnityEngine;
 
 [RequireComponent( typeof(InRoom) )]
 public class Spiker : Enemy {                                                  // a
     [Header("Inscribed: Skeletos")]                                              // b
     public int   speed = 4;
     public float timeThinkMin = 1f;
     public float timeThinkMax = 1f;
 
     [Header("Dynamic: Skeletos")]                                                // b
     [Range(0,4)]
     public int   facing = 0;
     public float timeNextDecision = 0;

     private InRoom inRm;                                                      // c
 
     protected override void Awake () {                                        // d
         base.Awake();
         inRm = GetComponent<InRoom>();
     }
 
     protected override void Update() {                                    // a
         base.Update();                                                    // b
         if ( knockback ) return;     

         if (Time.time >= timeNextDecision) {                                     // c
             DecideDirection();
         }
         // rigid is inherited from Enemy, which defines it in Enemy.Awake()
         rigid.velocity = directions[facing] * speed;
     }
 
     void DecideDirection() {                                                     // d
         facing = Random.Range(0, 5);
         timeNextDecision = Time.time + Random.Range(timeThinkMin, timeThinkMax);
     }

          public int GetFacing() { // This IS different from the Dray version!!!    // e
         return facing % 4;
     }
 
     public float GetSpeed() { return speed; }                  
     
     public bool moving {     // This IS different from the Dray version!!!    // f
         get { return (facing < 4); }
     }
     
     public float gridMult { get { return inRm.gridMult; } }              
         
     public bool isInRoom  { get { return inRm.isInRoom; } }
 
     public Vector2 roomNum {                          
         get { return inRm.roomNum; }
         set { inRm.roomNum = value; }
     }
 
     public Vector2 posInRoom {
         get { return inRm.posInRoom; }
         set { inRm.posInRoom = value; }
     }
 
     public Vector2 GetGridPosInRoom( float mult = -1 ) {
         return inRm.GetGridPosInRoom( mult );
     }
 
     // void Start() {…}  // Please delete the unused Start() method
 }


/*
[RequireComponent(typeof(DamageEffect))]
[RequireComponent(typeof(InRoom))]

public class Spiker : Enemy {
    enum eMode { search, attack, retract };

    [Header("Set in Inspector")]
    public float            sensorRange = 0.75f;
    public float            attackSpeed = 6;
    public float            retractSpeed = 3;
    public float            radius = 0.4f;

    private eMode           mode = eMode.search;
    private InRoom          inRm;
    private Dray            dray;
    private SphereCollider  drayColld;
    private Vector3         p0, p1;
    private DamageEffect    dEf;

    override protected void Start() {
        base.Start();

        inRm = GetComponent<InRoom>();

        GameObject go = GameObject.Find("Dray");
        dray = go.GetComponent<Dray>();
        drayColld = go.GetComponent<SphereCollider>();
        dEf = GetComponent<DamageEffect>();
        invincible = true;
    }
    

    override protected void Update() {
        switch (mode) {
            case eMode.search:
                // Check whether Dray is in the same room
                if (dray.roomNum != inRm.roomNum) return;

                float moveAmt;
                if ( Mathf.Abs( dray.roomPos.x - inRm.roomPos.x ) < sensorRange ) {
                    // Attack Vertically
                    moveAmt = ( InRoom.ROOM_H - (InRoom.WALL_T*2) )/2 - 1;//0.5f;
                    // The -0.5f above accounts for radius of Spiker
                    p1 = p0 = transform.position;
                    if (inRm.roomPos.y < InRoom.ROOM_H/2) {
                        p1.y += moveAmt; 
                    } else {
                        p1.y -= moveAmt;
                    }
                    mode = eMode.attack;
                }

                if ( Mathf.Abs( dray.roomPos.y - inRm.roomPos.y ) < sensorRange ) {
                    // Attack Horizontally
                    moveAmt = ( InRoom.ROOM_W - (InRoom.WALL_T*2) )/2 - 1;//0.5f;
                    p1 = p0 = transform.position;
                    if (inRm.roomPos.x < InRoom.ROOM_W/2) {
                        p1.x += moveAmt; 
                    } else {
                        p1.x -= moveAmt;
                    }
                    mode = eMode.attack;
                }
                break;
        }
    }

    void FixedUpdate() {
        Vector3 dir, pos, delta;

        switch (mode) {
            case eMode.attack:
                dir = (p1 - p0).normalized;
                pos = transform.position;
                delta = dir * attackSpeed * Time.fixedDeltaTime;
                if (delta.magnitude > (p1-pos).magnitude) {
                    // We're close enough to switch directions
                    transform.position = p1;
                    mode = eMode.retract;
                    break;
                }
                transform.position = pos + delta;
                break;

            case eMode.retract:
                dir = (p1 - p0).normalized;
                pos = transform.position;
                delta = dir * retractSpeed * Time.fixedDeltaTime;
                if (delta.magnitude > (p0-pos).magnitude) {
                    // We're close enough to switch directions
                    transform.position = p0;
                    mode = eMode.search;
                    break;
                }
                transform.position = pos - delta;
                break;

        }
	}   
}
*/